<template>
    <div>
      <h3>Search Hotels in:</h3>
      <input v-model="cityName" placeholder="Enter a city" />
      <button @click="getAvailableHotels">Search</button>
      <ul>
        <li v-for="hotel in hotels" :key="hotel.id">
          {{ hotel.name }}
        </li>
      </ul>
    </div>
  </template>
  
  <script>
  import { fetchAvailableHotels } from '../api.js';
  
  export default {
    data() {
      return {
        cityName: '',
        hotels: [],
      };
    },
    methods: {
      async getAvailableHotels() {
        this.hotels = await fetchAvailableHotels(this.cityName);
      },
    },
  };
  </script>