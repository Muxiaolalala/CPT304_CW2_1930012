<template>


  <div>


    
    <h1 style="white-space: nowrap;">Country Holidays List</h1>
    <select v-model="countryCode" @change="fetchHolidayData">
      <option value="" disabled selected>Select a country</option>
      <option v-for="country in countries" :key="country.code" :value="country.code">
        {{ country.name }}
      </option>
    </select>
    <button @click="toggleHolidaysList">{{ holidaysListButtonText }}</button>

    <div v-if="isLoading">
      <p>Loading public holiday information, please wait...</p>
    </div>
    <div v-else v-show="showHolidaysList">
      <h2>{{selectedCountryName}} Public Holidays</h2>
      <table>
        <thead>
          <tr>
            <th>Holiday</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="holiday in uniqueHolidays" :key="holiday.date.iso">
            <td>{{ holiday.name }}</td>
            <td>{{ formatDate(holiday.date.iso) }}</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
import { fetchHolidays } from '@/api';

export default {
  data() {
    return {
      countryCode: '',
      countries: [
  {
    name: 'United States',
    code: 'US',
  },
  {
    name: 'China',
    code: 'CN',
  },
  {
    name: 'Japan',
    code: 'JP',
  },
  {
    name: 'Germany',
    code: 'DE',
  },
  {
    name: 'India',
    code: 'IN',
  },
  {
    name: 'United Kingdom',
    code: 'GB',
  },
  {
    name: 'France',
    code: 'FR',
  },
  {
    name: 'Italy',
    code: 'IT',
  },
  {
    name: 'Brazil',
    code: 'BR',
  },
  {
    name: 'Canada',
    code: 'CA',
  },
  {
    name: 'Russia',
    code: 'RU',
  },
  {
    name: 'Korea, South',
    code: 'KR',
  },
  {
    name: 'Australia',
    code: 'AU',
  },
  {
    name: 'Spain',
    code: 'ES',
  },
  {
    name: 'Mexico',
    code: 'MX',
  },
  {
    name: 'Indonesia',
    code: 'ID',
  },
  {
    name: 'Netherlands',
    code: 'NL',
  },
  {
    name: 'Saudi Arabia',
    code: 'SA',
  },
  {
    name: 'Turkey',
    code: 'TR',
  },
  {
    name: 'Switzerland',
    code: 'CH',
  },
  {
    name: 'Poland',
    code: 'PL',
  },
  {
    name: 'Taiwan',
    code: 'TW',
  },
  {
    name: 'Sweden',
    code: 'SE',
  },
  {
    name: 'Belgium',
    code: 'BE',
  },
  {
    name: 'Argentina',
    code: 'AR',
  },
  {
    name: 'Thailand',
    code: 'TH',
  },
  {
    name: 'Iran',
    code: 'IR',
  },
  {
    name: 'Austria',
    code: 'AT',
  },
  {
    name: 'Norway',
    code: 'NO',
  },
  {
    name: 'United Arab Emirates',
    code: 'AE',
  },
  {
    name: 'Nigeria',
    code: 'NG',
  },
  {
    name: 'Israel',
    code: 'IL',
  },
  {
    name: 'South Africa',
    code: 'ZA',
  },
  {
    name: 'Hong Kong',
    code: 'HK',
  },
  {
    name: 'Ireland',
    code: 'IE',
  },
  {
    name: 'Denmark',
    code: 'DK',
  },
  {
    name: 'Singapore',
    code: 'SG',
  },
  {
    name: 'Malaysia',
    code: 'MY',
  },
  {
    name: 'Colombia',
    code: 'CO',
  },
  {
    name: 'Philippines',
    code: 'PH',
  },
  {
    name: 'Pakistan',
    code: 'PK',
  },
  {
    name: 'Chile',
    code: 'CL',
  },
  {
    name: 'Bangladesh',
    code: 'BD',
  },
  {
    name: 'Finland',
    code: 'FI',
  },
  {
    name: 'Egypt',
    code: 'EG',
  },
  {
    name: 'Vietnam',
    code: 'VN',
  },
  {
    name: 'Romania',
    code: 'RO',
  },
  {
    name: 'Czech Republic',
    code: 'CZ',
  },
  {
    name: 'Iraq',
    code: 'IQ',
  },
],
      holidays: [],
      isLoading: false,
      showHolidaysList: true,
    };
  },
  computed: {
    selectedCountryName() {
      const selected = this.countries.find(c => c.code === this.countryCode);
      return selected?.name ?? '';
    },
    uniqueHolidays() {
      const seen = new Map();
      return this.holidays.filter(holiday => {
        const key = `${holiday.name}${holiday.date.iso}`;
        if (seen.has(key)) {
          return false;
        }
        seen.set(key, true);
        return true;
      });
    },
    holidaysListButtonText() {
      if (this.showHolidaysList) {
        return 'Hide holidays';
      } else {
        return 'Show holidays';
      }
    },
  },
  methods: {
    formatDate(date) {
      if (!date) return '';
      return new Date(date).toLocaleDateString();
    },
    async fetchHolidayData() {
      this.isLoading = true;
      try {
        const data = await fetchHolidays(this.countryCode);
        this.holidays = data.response.holidays;
      } catch (error) {
        console.error('Error fetching holidays in the created hook:', error);
      } finally {
        this.isLoading = false;
      }
    },
    toggleHolidaysList() {
      this.showHolidaysList = !this.showHolidaysList;
    },
  },
};
</script>

<style>
#app {
  position: absolute;
  left: 0%;
  top: 0%;
}
</style>  