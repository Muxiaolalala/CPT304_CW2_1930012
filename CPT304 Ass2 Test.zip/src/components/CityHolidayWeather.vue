<template>
  <div class="weather-container" >
    <h1>City Holiday Weather</h1>
    <input v-model="city" type="text" placeholder="Enter city name" />
    <button @click="fetchData">Search</button>

    <div v-if="showData">
      <h2>Weather forecast for {{ city }}</h2>
      <ul>
  <li v-for="(day, i) in weatherList" :key="i">
    {{ formatDate(day.date) }} - 
    <span v-if="isHoliday(day.date)" class="bold">
      {{ getHoliday(day.date).name }}
    </span>
    <span v-else>
      No Holiday
    </span>
    - 
    <span v-if="day">
      {{ day.temp }}°C - {{ day.description }}
    </span>
    <span v-else>
      No weather data
    </span>
  </li>
</ul>
    </div>
  </div>
</template>
  
  <script>
  import { ref, computed } from "vue";
  import { fetchCityLocation, fetchWeather ,fetchHolidays} from "../api";
  
  export default {
    setup() {
      const holidays = ref([]);
      const city = ref("");
      const showData = ref(false);
      const weatherData = ref(null);
      const lat = ref(null);
      const lon = ref(null);
  
      const isHoliday = (date) => {
  const formattedDate = formatDate(date);
  return holidays.value.some(holiday => holiday.date.iso === formattedDate);
};

const getHoliday = (date) => {
  const formattedDate = formatDate(date);
  return holidays.value.find(holiday => holiday.date.iso === formattedDate);
};

      const fetchData = async () => {
        try {
          await fetchCityData();
          await fetchHolidaysData(); 
          const weather = await fetchWeather(lat.value, lon.value);
          weatherData.value = weather.forecast;
          showData.value = true;
        } catch (error) {
          console.error("Error fetching weather data:", error);
        }
      };
  
      const fetchCityData = async () => {
        try {
          const cityData = await fetchCityLocation(city.value);
          lat.value = cityData.geometry.lat;
          lon.value = cityData.geometry.lng;
        } catch (error) {
          console.error("Error fetching city location:", error);
        }
      };
  
      const fetchHolidaysData = async () => {
  try {
    const cityData = await fetchCityLocation(city.value);
    const countryCode = cityData.components['ISO_3166-1_alpha-2'];
    const holidayData = await fetchHolidays(countryCode);
    holidays.value = holidayData.response.holidays;
    console.log("Holidays data:", holidays.value); // Debug log
  } catch (error) {
    console.error("Error fetching holidays:", error);
  }
};

const formatDate = (timestamp) => {
  if (!timestamp) return "";
  const dateObject = new Date(timestamp * 1000);
  const year = dateObject.getFullYear();
  const month = String(dateObject.getMonth() + 1).padStart(2, '0'); // Month is zero-indexed
  const day = String(dateObject.getDate()).padStart(2, '0'); 
  return `${year}-${month}-${day}`; // Return the date in ISO format, e.g., "YYYY-MM-DD"
};
  
const weatherList = computed(() => {
  if (!weatherData.value || !weatherData.value.forecastday) {
    return [];
  }
  return weatherData.value.forecastday.map((day) => ({
    date: day.date_epoch,
    temp: day.day.avgtemp_c,
    description: day.day.condition.text,
  }));
});
  
      return {
        city,
        fetchData,
        showData,
        weatherList,
        formatDate,
        fetchHolidaysData,
        isHoliday,
        getHoliday,
      };
    },
  };
  </script>
  
  <style scoped>
.bold {
  font-weight: bold;
}
input, button {
  font-size: 1.3em;
  padding: 0.3em;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  margin-bottom: 0.5em;
}

.weather-container {
  position: fixed;
  top: 5%;
  right: 10%;
  
  padding: 2em;
  box-sizing: border-box;
}
</style>