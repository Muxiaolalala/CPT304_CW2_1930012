import axios from 'axios';

const API_KEYS = {
  openCage: 'cae165bf797645d49b54e7e5392c0030',
  weather: 'b2345cec738e494aa26150333230605',
  calendarific: '227e21408d0eb46cb219e500dcab2db90b643996',
  openTripMap: '5ae2e3f221c38a28845f05b69c92cc5c9f63da31e473680b0fdc3f10',
};

const apiClient = {
  calendarific: axios.create({
    baseURL: 'https://calendarific.com/api/v2',
    timeout: 5000,
  }),
  openCage: axios.create({
    baseURL: 'https://api.opencagedata.com/geocode/v1',
    timeout: 5000,
  }),
  weather: axios.create({
    baseURL: 'https://api.weatherapi.com/v1',
    timeout: 5000,
  }),
  openTripMap: axios.create({
    baseURL: 'https://api.opentripmap.com/0.1/geo',
    timeout: 5000,
  }),
};

export const fetchHolidays = async (countryCode) => {
  try {
    const response = await apiClient.calendarific.get(`/holidays?api_key=${API_KEYS.calendarific}&country=${countryCode}&year=2023`);
    return response.data;
  } catch (error) {
    console.error('Error fetching holidays:', error);
    throw error;
  }
};

export const fetchCityLocation = async (city) => {
  const { data } = await apiClient.openCage.get(`/json?q=${city}&key=${API_KEYS.openCage}`);
  return data.results[0];
};

export const fetchWeather = async (lat, lon) => {
  const { data } = await apiClient.weather.get(`/forecast.json?key=${API_KEYS.weather}&q=${lat},${lon}&days=7`);
  return data;
};

export const fetchAvailableHotels = async (cityName) => {
  try {
    const { data } = await apiClient.openTripMap.get(`/search?x-apikey=${API_KEYS.openTripMap}&city=${cityName}&kind=accommodation&radius=10000&count=20`);
    return data.features;
  } catch (error) {
    console.error('Error fetching hotels:', error);
    return [];
  }
};