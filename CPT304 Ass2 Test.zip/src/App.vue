<template>
  <div id="app">
    <HolidayList></HolidayList>
    <CityHolidayWeather></CityHolidayWeather>
    <RentalList></RentalList>
  </div>
</template>

<script>
import HolidayList from '@/components/HolidayList.vue';
import CityHolidayWeather from '@/components/CityHolidayWeather.vue';
import RentalList from '@/components/RentalList.vue';

export default {
  name: 'App',
  components: {
    HolidayList,
    CityHolidayWeather,
    RentalList
  },
};
</script>

<style>
#app {
  position: absolute  ;
  left: 0%;
  top: 5%;
  width: 100%;
  height: 100%;
}

.component-spacing {
  margin-top: 2rem;
}
</style>